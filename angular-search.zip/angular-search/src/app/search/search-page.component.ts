import { Observable } from 'rxjs';
import { Component } from '@angular/core';
import { HttpService } from 'src/shared/http/http.service';
import { catchError, debounceTime, distinctUntilChanged, filter, map, onErrorResumeNext, pluck, switchMap, tap } from 'rxjs/operators';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { of } from 'rxjs';

@Component({
  selector: 'app-search-page',
  templateUrl: './search-page.component.html',
  styleUrls: ['./search-page.component.scss']
})
export class SearchPageComponent {

  searchForm: FormGroup;
  nearByLandmark: FormControl;

  data:any;

  constructor(private httpService: HttpService, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.searchForm = this.formBuilder.group({
      nearByLandmark: new FormControl('', [Validators.required, Validators.minLength(3)])
    });
  }

  onInputChange(event: string) {
    if (event.length < 3) {
      return
    }
    let payload = { "search": "mark", "city_id": 27 }
    // this.httpService.getLandMarks(payload).subscribe(
    //   (res) => console.log(res),
    //   (err) => console.log(err)
    // )
  }

  ngAfterViewInit(): void {
    const formValue = this.searchForm.valueChanges;
    formValue.pipe(
      pluck('nearByLandmark'),
      debounceTime(250),
      distinctUntilChanged(),
      switchMap(data => this.httpService.getLandMarks({ "search": data, "city_id": 27 }))
    ).subscribe(res => {
      console.log(res);
      this.data = res.body.data;

    })
  }

  goNext(data){
    console.log(data);
  }
  clearField(){
    this.searchForm.controls.nearByLandmark.setValue('');
    this.data = ''
  }
}
