import { Component } from '@angular/core'

@Component({
    selector: 'view-component',
    templateUrl: 'view-component.html'
})

export class ViewComponent {

    text:string = 'TEXT';
    inputText(event:string){
        console.log(event);

        this.text= event
        
    }
}